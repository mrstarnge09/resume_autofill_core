import os
from google import genai
from playwright.sync_api import sync_playwright
from config import (
    DEFAULT_ROLES,
    DEFAULT_START_URL,
    SAFE_COMPANIES,
    WORLD_LOCATIONS,
    normalize_url
)
from form_filler import fill_active_page
from surf_matrix import build_engine_url, build_permutation_matrix
from tracker import log_event


def run_cli():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise ValueError("Set GEMINI_API_KEY environment variable first.")

    start_in = input("Start URL (press ENTER for LinkedIn Jobs): ").strip()
    roles_in = input(f"Roles (comma-sep, default {len(DEFAULT_ROLES)} roles): ").strip()
    locs_in = input(f"Locations (comma-sep, default {len(WORLD_LOCATIONS)} global hubs): ").strip()
    comps_in = input(f"Safe Companies (comma-sep, default {len(SAFE_COMPANIES)} companies): ").strip()

    roles = [r.strip() for r in roles_in.split(",") if r.strip()] or DEFAULT_ROLES
    locations = [l.strip() for l in locs_in.split(",") if l.strip()] or WORLD_LOCATIONS
    companies = [c.strip() for c in comps_in.split(",") if c.strip()] or SAFE_COMPANIES

    matrix = build_permutation_matrix(roles, locations, companies)
    clean_start = normalize_url(start_in, DEFAULT_START_URL)
    client = genai.Client(api_key=api_key)

    print(f"[*] Loaded {len(matrix)} permutations.")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=30)
        context = browser.new_context(viewport={"width": 1366, "height": 850})
        page = context.new_page()
        page.goto(clean_start, wait_until="domcontentloaded")

        idx = 0
        while True:
            if not browser.is_connected():
                print("[!] Browser closed. Exiting cleanly.")
                break

            active_page = context.new_page() if not context.pages else context.pages[-1]
            item = matrix[idx % len(matrix)]

            print(f"\n[{idx + 1}/{len(matrix)}] [{item['dimension']}] {item['query']}")
            cmd = input(
                "[ENTER] fill active tab | [s] surf Google | [b] Bing | [d] DuckDuckGo | "
                "[u] open URL & fill | [q] quit: "
            ).strip().lower()

            if cmd == "q":
                break
            elif cmd in ("s", "b", "d"):
                engine = {"s": "google", "b": "bing", "d": "duckduckgo"}[cmd]
                url = build_engine_url(item["query"], engine)
                active_page.goto(url, wait_until="domcontentloaded")
                log_event(f"surf_{engine}", item["dimension"], item["query"], active_page.url)
                idx += 1
            elif cmd == "u":
                raw_target = input("Paste application URL: ").strip()
                if raw_target:
                    target_url = normalize_url(raw_target, fallback="")
                    if target_url:
                        active_page.goto(target_url, wait_until="domcontentloaded")
                        active_page.wait_for_timeout(1200)
                        filled, total = fill_active_page(client, active_page)
                        log_event("autofill_url", item["dimension"], item["query"], active_page.url, filled, total)
            else:
                filled, total = fill_active_page(client, active_page)
                log_event("autofill_tab", item["dimension"], item["query"], active_page.url, filled, total)

        if browser.is_connected():
            browser.close()


if __name__ == "__main__":
    run_cli()

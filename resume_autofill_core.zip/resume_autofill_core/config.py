import os
import re

GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")
RESUME_FILE_PATH = os.path.abspath("Sagar_Raj_Resume.docx")
LOG_CSV_PATH = os.path.abspath("applications_log.csv")
DEFAULT_START_URL = "https://www.linkedin.com/jobs"

VERIFIED_PROFILE = {
    "name": "Sagar Raj",
    "first_name": "Sagar",
    "last_name": "Raj",
    "headline": "2026 BCA (Data Science) Graduate | Data Science & ML Engineer",
    "dob": "2000-04-27",
    "location": "Bengaluru, Karnataka, India",
    "city": "Bengaluru",
    "state": "Karnataka",
    "country": "India",
    "postal_code": "560119",
    "origin": "Barachatti, Gaya, Bihar, India",
    "phone": "+91 6287652415",
    "email": "sagarrajr09@gmail.com",
    "linkedin": "https://www.linkedin.com/in/sagar-raj-1144222a7/",
    "github": "",
    "willing_to_relocate_worldwide": True,
    "remote_friendly": True,
    "education": [
        {
            "degree": "Bachelor of Computer Applications (Data Science)",
            "institution": "Presidency University, Bengaluru",
            "period": "2023–2026",
            "cgpa": ""
        },
        {
            "degree": "Class XII",
            "institution": "Al-Momin International School",
            "year": "2023"
        },
        {
            "degree": "Class X",
            "institution": "DAV Public School",
            "year": "2020"
        }
    ],
    "certifications": [
        "Google: Introduction to Data Analytics in Google Cloud",
        "Google Professional Machine Learning Engineer exam preparation (in progress)"
    ],
    "skills": [
        "Python", "SQL (BigQuery)", "PowerShell", "VBScript",
        "Scikit-learn", "XGBoost", "Random Forest", "Feature Engineering",
        "NLP", "OpenCV", "Gemini API", "Pandas", "ETL Pipelines",
        "Google Cloud (Vertex AI, BigQuery)", "AWS", "Flask", "Streamlit",
        "Git", "Linux CLI", "REST APIs", "Tkinter", "OpenSCAD",
        "3D Printing", "PCB Design (Gerber/BOM)", "ESP8266"
    ],
    "projects": [
        {
            "name": "EV Battery State of Health Prediction",
            "stack": "XGBoost, Python, Streamlit",
            "summary": "Estimated battery SoH from telemetry using Arrhenius thermal stress and C-rate features, tuned for end-of-life (SoH < 80%) with weighted MAPE, and deployed a Streamlit telemetry dashboard."
        },
        {
            "name": "DailyHabitAI – Local Task Prediction Assistant",
            "stack": "Python, Scikit-learn, Pandas, Windows API",
            "summary": "Trained a Random Forest on task-sequence history with privacy-first append-only JSON logging and silent login startup via pythonw and VBScript."
        },
        {
            "name": "AI Vision Object Detector with HUD",
            "stack": "Python, OpenCV, Gemini API",
            "summary": "Built live webcam object detection and Gemini API scene/object descriptions in a real-time multi-window HUD."
        },
        {
            "name": "Reverse-Image Search Web App",
            "stack": "Flask, SerpAPI",
            "summary": "Built a Flask web app for face detection, reverse-image search, and structured match reports."
        }
    ],
    "connections_and_alumni": {
        "connections_1st": [],
        "alumni_org": "Presidency University"
    }
}

DEFAULT_ROLES = [
    "Data Scientist",
    "Machine Learning Engineer",
    "Python Developer"
]

WORLD_LOCATIONS = [
    "Remote", "Bengaluru", "Hyderabad", "Pune", "Mumbai", "Chennai", "Gurugram",
    "Singapore", "Dubai", "London", "Berlin", "Amsterdam", "Toronto",
    "San Francisco", "New York", "Austin", "Seattle", "Sydney", "Tokyo"
]

SAFE_COMPANIES = [
    "Google", "Microsoft", "Amazon", "Deloitte", "HCLTech", "CGI",
    "Accenture", "Capgemini", "IBM", "Oracle", "SAP", "NVIDIA",
    "Siemens", "Bosch", "Cisco", "Thoughtworks", "Atlassian", "Stripe"
]


def normalize_url(raw_url: str, fallback: str = DEFAULT_START_URL) -> str:
    text = (raw_url or "").strip()
    md_match = re.search(r"\[[^\]]*\]\(([^)]+)\)", text)
    if md_match:
        text = md_match.group(1).strip()
    text = text.strip("<>\"' ")
    if not text:
        text = fallback
    if not re.match(r"^https?://", text, flags=re.IGNORECASE):
        text = "https://" + text.lstrip("/")
    return text

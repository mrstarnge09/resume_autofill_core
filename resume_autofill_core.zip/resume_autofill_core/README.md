# Resume Autofill Core

Modular Python system for surfing global job & network permutations and filling application forms cleanly.

## Setup

```bash
pip install -r requirements.txt
playwright install chromium
set GEMINI_API_KEY=your_api_key_here
python main.py
```

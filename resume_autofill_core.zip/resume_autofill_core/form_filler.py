import json
import os
from google import genai
from google.genai import types
from config import GEMINI_MODEL, RESUME_FILE_PATH, VERIFIED_PROFILE

READ_ONLY_SCAN_JS = """
() => {
    function getLabel(el) {
        if (el.id) {
            const lbl = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
            if (lbl && lbl.innerText.trim()) return lbl.innerText.trim();
        }
        const parentLbl = el.closest('label');
        if (parentLbl && parentLbl.innerText.trim()) return parentLbl.innerText.trim();

        const aria = el.getAttribute('aria-label');
        if (aria && aria.trim()) return aria.trim();

        const ariaBy = el.getAttribute('aria-labelledby');
        if (ariaBy) {
            const ref = document.getElementById(ariaBy);
            if (ref && ref.innerText.trim()) return ref.innerText.trim();
        }

        let box = el.parentElement;
        for (let i = 0; i < 4 && box; i++) {
            const texts = Array.from(box.querySelectorAll('label, span, div, p, h3, h4'))
                .map(n => n.innerText?.trim())
                .filter(t => t && t.length > 1 && t.length < 220);
            if (texts.length > 0) return texts[0];
            box = box.parentElement;
        }
        return el.name || el.placeholder || '';
    }

    const nodes = Array.from(
        document.querySelectorAll('input, textarea, select, [role="combobox"], [role="listbox"]')
    );

    const fields = [];
    nodes.forEach((el, domIndex) => {
        const type = (el.getAttribute('type') || el.tagName).toLowerCase();
        if (['hidden', 'submit', 'button', 'image', 'reset'].includes(type)) return;

        const style = window.getComputedStyle(el);
        if (type !== 'file' && (style.display === 'none' || style.visibility === 'hidden')) return;

        let options = [];
        if (el.tagName.toLowerCase() === 'select') {
            options = Array.from(el.options).map(o => o.text.trim()).filter(Boolean);
        }

        fields.push({
            dom_index: domIndex,
            tag: el.tagName.toLowerCase(),
            type: type,
            name: el.name || '',
            id: el.id || '',
            placeholder: el.placeholder || '',
            label: getLabel(el),
            required: el.required || el.getAttribute('aria-required') === 'true',
            options: options
        });
    });

    return fields;
}
"""


def _parse_json(raw_text: str) -> dict:
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()
    return json.loads(cleaned)


def fill_active_page(client: genai.Client, page) -> tuple[int, int]:
    """Returns (filled_count, detected_count) without mutating DOM attributes."""
    extracted = []
    for frame_idx, frame in enumerate(page.frames):
        try:
            items = frame.evaluate(READ_ONLY_SCAN_JS)
            for item in items:
                item["frame_idx"] = frame_idx
                item["key"] = f"f{frame_idx}_i{item['dom_index']}"
            extracted.extend(items)
        except Exception:
            continue

    if not extracted:
        print("[!] No fillable form fields found on the current page.")
        return 0, 0

    prompt = f"""
Map the candidate's verified profile, education, skills, and projects to the web form fields below.
Return ONLY a valid JSON object mapping each field's `key` to its exact string value.
Rules:
- For dropdowns/selects (`options` non-empty), return the exact matching option string from `options`.
- For open-ended questions, write concise, truthful answers from the candidate's BCA Data Science background and projects.
- For file upload inputs (`type == "file"`), return "UPLOAD_RESUME".
- Omit fields that should not be filled.

CANDIDATE_PROFILE:
{json.dumps(VERIFIED_PROFILE, indent=2)}

FORM_FIELDS:
{json.dumps(extracted, indent=2)}
"""

    res = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            temperature=0.1,
        ),
    )
    mapping = _parse_json(res.text)

    filled_count = 0
    for field in extracted:
        val = str(mapping.get(field["key"], "")).strip()
        if not val:
            continue

        frame = page.frames[field["frame_idx"]]
        locator = frame.locator(
            'input, textarea, select, [role="combobox"], [role="listbox"]'
        ).nth(field["dom_index"])

        try:
            if field["type"] == "file" and val == "UPLOAD_RESUME":
                if os.path.exists(RESUME_FILE_PATH):
                    locator.set_input_files(RESUME_FILE_PATH)
                    filled_count += 1
                    print(f"  [+] Uploaded Resume -> {field['label'][:45]}")
                else:
                    print(f"  [!] Resume not found: {RESUME_FILE_PATH}")

            elif field["tag"] == "select":
                try:
                    locator.select_option(label=val)
                except Exception:
                    locator.select_option(value=val)
                filled_count += 1
                print(f"  [+] Selected '{val}' -> {field['label'][:45]}")

            elif field["type"] in ("checkbox", "radio"):
                if val.lower() in ("true", "yes", "1", "checked"):
                    locator.check()
                    filled_count += 1
                    print(f"  [+] Checked -> {field['label'][:45]}")

            else:
                locator.click()
                locator.fill("")
                locator.type(val, delay=12)
                filled_count += 1
                print(f"  [+] Filled '{val[:35]}' -> {field['label'][:45]}")

        except Exception as e:
            print(f"  [-] Skipped '{field['label'][:35]}': {e}")

    print(f"[DONE] Cleanly filled {filled_count}/{len(extracted)} fields.")
    return filled_count, len(extracted)

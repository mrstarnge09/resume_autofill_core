import itertools
from urllib.parse import quote_plus
from config import VERIFIED_PROFILE


def build_permutation_matrix(roles: list, locations: list, companies: list) -> list:
    conns = VERIFIED_PROFILE["connections_and_alumni"]["connections_1st"]
    alumni = VERIFIED_PROFILE["connections_and_alumni"]["alumni_org"]
    skills = ["Python", "XGBoost", "Scikit-learn", "BigQuery", "OpenCV", "Gemini API"]
    channels = [
        "site:linkedin.com/in",
        "site:linkedin.com/jobs",
        "site:boards.greenhouse.io",
        "site:jobs.lever.co",
        "site:myworkdayjobs.com",
        "site:github.com"
    ]

    matrix = []

    for conn, company, loc in itertools.product(conns, companies, locations):
        matrix.append({
            "dimension": "CONN_COMPANY_LOC",
            "query": f'site:linkedin.com/in "{conn}" "{company}" "{loc}"'
        })

    for conn, company in itertools.product(conns, companies):
        matrix.append({
            "dimension": "CONN_ALUMNI_COMPANY",
            "query": f'"{conn}" "{alumni}" "{company}"'
        })

    for company, role, loc in itertools.product(companies, roles[:2], locations):
        matrix.append({
            "dimension": "ALUMNI_COMPANY_ROLE_LOC",
            "query": f'site:linkedin.com/in "{alumni}" "{company}" "{role}" "{loc}"'
        })

    for company, role, skill, loc in itertools.product(companies, roles[:2], skills[:3], locations[:6]):
        matrix.append({
            "dimension": "COMPANY_ROLE_SKILL_LOC",
            "query": f'"{company}" "{role}" "{skill}" "{loc}"'
        })

    for channel, company, role, loc in itertools.product(channels, companies[:8], roles[:2], locations[:5]):
        matrix.append({
            "dimension": "CHANNEL_MATRIX",
            "query": f'{channel} "{company}" "{role}" "{loc}"'
        })

    return matrix


def build_engine_url(query: str, engine: str = "google") -> str:
    q = quote_plus(query)
    engines = {
        "google": f"https://www.google.com/search?q={q}",
        "bing": f"https://www.bing.com/search?q={q}",
        "duckduckgo": f"https://duckduckgo.com/?q={q}"
    }
    return engines.get(engine, engines["google"])

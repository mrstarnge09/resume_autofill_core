import csv
import os
from datetime import datetime
from config import LOG_CSV_PATH

FIELDNAMES = [
    "timestamp",
    "action",
    "dimension",
    "query",
    "page_url",
    "filled_count",
    "detected_count"
]


def log_event(
    action: str,
    dimension: str = "",
    query: str = "",
    page_url: str = "",
    filled_count: int = 0,
    detected_count: int = 0
):
    file_exists = os.path.exists(LOG_CSV_PATH)
    with open(LOG_CSV_PATH, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        if not file_exists:
            writer.writeheader()
        writer.writerow({
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "action": action,
            "dimension": dimension,
            "query": query,
            "page_url": page_url,
            "filled_count": filled_count,
            "detected_count": detected_count
        })
